# ShopEase Version 2

A beginner-friendly React shopping storefront with Supabase authentication, product catalogue, cart, wishlist, demo order creation, customer order history and an admin dashboard.

## Important before you launch

This is a learning / MVP starter. The included checkout is **demo order creation only**. It does not collect money. Do not accept real payments or rely on client-submitted totals for paid orders. A production payment flow must create orders on a trusted server, verify Razorpay signatures server-side, validate prices and stock server-side, and update order status only after trusted payment confirmation.

## 1. Create the free online accounts

1. Create a GitHub account at https://github.com if you do not already have one.
2. Create a Supabase account at https://supabase.com and create a new project. Save the database password somewhere private.
3. Create a Netlify account at https://app.netlify.com and connect it to GitHub. Netlify's current Free plan permits commercial projects within its monthly usage limits.

Supabase's free tier is intended for experiments and small projects; free projects may pause after a week of inactivity and have quotas. Vercel Hobby is free for personal, non-commercial use. Check current plan terms before using these services for a commercial store.

## 2. Open this project in a browser editor

Option A — StackBlitz:
1. Open https://stackblitz.com/
2. Choose **Import project** / **Upload project** if available, and upload the extracted ShopEase folder or its GitHub repository.
3. Wait for dependencies to install. The preview should show the storefront.
4. If you use GitHub, create a new empty repository, upload the contents of this folder, then open that repository in StackBlitz.

Option B — GitHub Codespaces:
1. Upload the project files to a new GitHub repository.
2. On the repository page choose **Code → Codespaces → Create codespace**.
3. In the terminal run `npm install` and then `npm run dev -- --host 0.0.0.0`.
4. Open the forwarded port 5173 preview.

## 3. Create the database

1. Open your Supabase project.
2. Select **SQL Editor → New query**.
3. Open `supabase/schema.sql` in the project and copy all its contents.
4. Paste into the SQL Editor and click **Run**.
5. The script creates customer profiles, products, orders, order items and row-level security policies.

## 4. Connect the website to Supabase

1. In Supabase open **Project Settings → API** (or **API Keys**).
2. Copy the Project URL.
3. Copy the publishable key (or legacy anon public key). Never use the `service_role` key in browser code.
4. In the browser editor, create a file named `.env` in the project root. Copy the lines below and replace the placeholders:

```env
VITE_SUPABASE_URL=https://YOUR-PROJECT.supabase.co
VITE_SUPABASE_ANON_KEY=YOUR_PUBLIC_PUBLISHABLE_OR_ANON_KEY
```

5. Restart the dev server / refresh the preview. Vite environment variables are read when the server starts.
6. In Supabase **Authentication → URL Configuration**, set the Site URL to your deployed website URL when you have deployed. Add your StackBlitz preview URL during development if needed.

## 5. Make your account an administrator

1. Open the website and create an account using the Account button.
2. Confirm your email if Supabase asks you to.
3. In Supabase open **Table Editor → profiles**.
4. Find the row whose `id` matches your new user's ID in **Authentication → Users**.
5. Change `role` from `customer` to `admin` and save.
6. Sign out and sign back in. The Admin dashboard will appear below the storefront.

Never allow a public signup form to choose its own role. Only change the role from the trusted Supabase dashboard.

## 6. Publish the website for free

1. Push the project folder to GitHub. Do not commit `.env` or any secret keys.
2. In Netlify choose **Add new site → Import an existing project** and connect your GitHub repository.
3. Set the build command to `npm run build` and publish directory to `dist` (Netlify often detects Vite automatically).
4. In **Site configuration → Environment variables**, add:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
5. Deploy. After deployment, add the public Netlify URL to Supabase Authentication URL Configuration and allowed redirect URLs.
6. Redeploy if you changed environment variables. Netlify's Free plan currently includes 300 monthly credits; projects can pause after reaching the limit.

## 7. What works in this starter

- Responsive storefront, product search and category filters
- Cart quantity controls and wishlist (kept in React state during the current visit)
- Supabase email/password signup and login
- Products loaded from Supabase; sample catalogue in SQL
- Admin-only add/hide product controls
- Customer demo orders, order history and admin status updates
- Row Level Security policies for the database

## 8. Before real customers / real payments

This starter is not yet a production commerce system. Before selling:
- Build a trusted server-side checkout endpoint (for example a Supabase Edge Function) that reads product prices from the database and creates the Razorpay order.
- Keep the Razorpay Key Secret only in server-side secrets, never in `.env` variables prefixed with `VITE_`.
- Verify the Razorpay payment signature on the server using the server-created order ID and secret; confirm payment status before marking an order paid. Follow Razorpay's current official integration docs.
- Add stock reservation/decrement logic, server-side price calculations, webhook handling, cancellation/refund handling, tax/shipping rules, privacy policy, terms, returns policy and customer support details.
- Test permissions using a normal customer account and a separate admin account.
- Review Supabase and Netlify quotas/terms. Netlify currently allows commercial projects on its Free plan within the monthly credit limit, but the site can pause if the limit is reached. Supabase Free projects can pause after a week of inactivity.

## Useful official docs

- Supabase: https://supabase.com/docs
- Supabase Auth: https://supabase.com/docs/guides/auth
- Supabase Row Level Security: https://supabase.com/docs/guides/database/postgres/row-level-security
- Vite: https://vite.dev/guide/
- Netlify: https://docs.netlify.com/
- Razorpay Standard Checkout: https://razorpay.com/docs/payments/payment-gateway/web-integration/standard/

## Troubleshooting

- **Blank preview:** check the browser editor console and wait for `npm install` to finish.
- **Supabase missing configuration:** ensure `.env` is at the project root, variable names start with `VITE_`, and restart the dev server.
- **Email confirmation:** check the inbox / spam folder. Configure Supabase auth URLs for your preview/deployed domain.
- **Admin panel missing:** update your own `profiles.role` to `admin`, then sign out and back in.
- **Products not loading:** make sure the SQL script ran successfully and the `products` table has active rows.
