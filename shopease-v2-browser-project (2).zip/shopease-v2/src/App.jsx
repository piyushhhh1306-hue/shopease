import { useEffect, useMemo, useState } from 'react';
import { supabase, isSupabaseConfigured } from './supabase';
import { Search, ShoppingBag, Heart, User, Plus, Minus, Trash2, X, LogOut, Package, ShieldCheck, Menu } from 'lucide-react';

const demoProducts = [
 {id:'demo-1',name:'Everyday Tote Bag',category:'Accessories',price:799,emoji:'👜',description:'A roomy everyday carry-all.',stock:12},
 {id:'demo-2',name:'Minimal Ceramic Mug',category:'Home',price:449,emoji:'☕',description:'A simple mug for slow mornings.',stock:18},
 {id:'demo-3',name:'Wireless Headphones',category:'Electronics',price:2199,emoji:'🎧',description:'Comfortable sound for every day.',stock:8},
 {id:'demo-4',name:'Classic Wrist Watch',category:'Accessories',price:1599,emoji:'⌚',description:'A clean, timeless everyday style.',stock:7},
 {id:'demo-5',name:'Soft Knit Sweater',category:'Fashion',price:1299,emoji:'🧥',description:'A cosy layer for cooler days.',stock:14},
 {id:'demo-6',name:'Desk Plant Pot',category:'Home',price:599,emoji:'🪴',description:'A little green for your workspace.',stock:20},
 {id:'demo-7',name:'Everyday Sneakers',category:'Fashion',price:1899,emoji:'👟',description:'Easy comfort for daily walks.',stock:9},
 {id:'demo-8',name:'Portable Speaker',category:'Electronics',price:1799,emoji:'🔊',description:'Bring your favourite music along.',stock:11}
];
const categories=['All','Fashion','Electronics','Home','Accessories'];
const money=n=>'₹'+Number(n||0).toLocaleString('en-IN');
const cleanProduct=p=>({...p,price:Number(p.price),emoji:p.emoji||'🛍️'});

export default function App(){
 const [products,setProducts]=useState(demoProducts);
 const [session,setSession]=useState(null);
 const [profile,setProfile]=useState(null);
 const [cart,setCart]=useState({});
 const [wishlist,setWishlist]=useState([]);
 const [category,setCategory]=useState('All');
 const [search,setSearch]=useState('');
 const [drawer,setDrawer]=useState('');
 const [authMode,setAuthMode]=useState('login');
 const [email,setEmail]=useState('');
 const [password,setPassword]=useState('');
 const [fullName,setFullName]=useState('');
 const [message,setMessage]=useState('');
 const [orders,setOrders]=useState([]);
 const [adminForm,setAdminForm]=useState({name:'',category:'Home',price:'',emoji:'📦',description:'',stock:'10'});
 const [busy,setBusy]=useState(false);
 const isAdmin=profile?.role==='admin';

 useEffect(()=>{
  if(!isSupabaseConfigured)return;
  supabase.auth.getSession().then(({data})=>setSession(data.session));
  const {data:{subscription}}=supabase.auth.onAuthStateChange((_event,next)=>setSession(next));
  return ()=>subscription.unsubscribe();
 },[]);
 useEffect(()=>{
  if(!isSupabaseConfigured)return;
  (async()=>{
   const {data,error}=await supabase.from('products').select('*').eq('active',true).order('created_at',{ascending:false});
   if(!error && data?.length)setProducts(data.map(cleanProduct));
  })();
 },[]);
 useEffect(()=>{
  if(!session || !isSupabaseConfigured){setProfile(null);setOrders([]);return}
  (async()=>{
   const {data}=await supabase.from('profiles').select('*').eq('id',session.user.id).maybeSingle();
   setProfile(data);
   const {data:rows}=await supabase.from('orders').select('id,total,status,created_at,order_items(product_name,quantity,unit_price)').order('created_at',{ascending:false});
   setOrders(rows||[]);
  })();
 },[session]);
 const visible=useMemo(()=>products.filter(p=>(category==='All'||p.category===category)&&p.name.toLowerCase().includes(search.toLowerCase())),[products,category,search]);
 const cartItems=products.filter(p=>cart[p.id]>0);
 const subtotal=cartItems.reduce((s,p)=>s+p.price*cart[p.id],0);
 const shipping=subtotal===0||subtotal>=1999?0:99;
 const total=subtotal+shipping;
 const count=Object.values(cart).reduce((a,b)=>a+b,0);
 const notify=t=>{setMessage(t);setTimeout(()=>setMessage(''),3000)};
 const add=p=>setCart(c=>({...c,[p.id]:(c[p.id]||0)+1}));
 const change=(id,by)=>setCart(c=>{const n=(c[id]||0)+by;const next={...c};if(n<=0)delete next[id];else next[id]=n;return next});
 const toggleWish=id=>setWishlist(w=>w.includes(id)?w.filter(x=>x!==id):[...w,id]);
 async function authSubmit(e){
  e.preventDefault();if(!isSupabaseConfigured){notify('Connect Supabase first using the setup guide.');return}
  setBusy(true);
  const result=authMode==='signup'
   ? await supabase.auth.signUp({email,password,options:{data:{full_name:fullName}}})
   : await supabase.auth.signInWithPassword({email,password});
  setBusy(false);notify(result.error?.message || (authMode==='signup'?'Check your email to confirm your account.':'Welcome back!'));
 }
 async function logout(){await supabase.auth.signOut();setDrawer('');notify('You have signed out.')}
 async function placeDemoOrder(){
  if(!session){setDrawer('account');notify('Please log in before placing an order.');return}
  if(!cartItems.length)return;
  if(!isSupabaseConfigured){notify('Connect Supabase to save orders.');return}
  setBusy(true);
  const {data:order,error}=await supabase.from('orders').insert({user_id:session.user.id,total,status:'demo_pending'}).select().single();
  if(error){setBusy(false);notify(error.message);return}
  const rows=cartItems.map(p=>({order_id:order.id,product_id:p.id.startsWith('demo-')?null:p.id,product_name:p.name,quantity:cart[p.id],unit_price:p.price}));
  const {error:itemError}=await supabase.from('order_items').insert(rows);
  setBusy(false);
  if(itemError){notify('Order created but items could not be saved: '+itemError.message);return}
  setCart({});setDrawer('');notify('Demo order placed! No payment was collected.');
  const {data}=await supabase.from('orders').select('id,total,status,created_at,order_items(product_name,quantity,unit_price)').order('created_at',{ascending:false});setOrders(data||[]);
 }
 async function addProduct(e){
  e.preventDefault();if(!isSupabaseConfigured||!isAdmin){notify('Admin access and Supabase are required.');return}
  const {error}=await supabase.from('products').insert({...adminForm,price:Number(adminForm.price),stock:Number(adminForm.stock),active:true});
  if(error){notify(error.message);return}
  const {data}=await supabase.from('products').select('*').eq('active',true).order('created_at',{ascending:false});
  setProducts((data||[]).map(cleanProduct));setAdminForm({name:'',category:'Home',price:'',emoji:'📦',description:'',stock:'10'});notify('Product added!');
 }
 async function deleteProduct(id){
  const {error}=await supabase.from('products').update({active:false}).eq('id',id);
  if(error){notify(error.message);return}
  setProducts(p=>p.filter(x=>x.id!==id));notify('Product hidden from the store.');
 }
 async function updateStatus(id,status){
  const {error}=await supabase.from('orders').update({status}).eq('id',id);
  if(error){notify(error.message);return}
  setOrders(o=>o.map(x=>x.id===id?{...x,status}:x));notify('Order status updated.');
 }

 return <div>
  <div className="announcement">FREE SHIPPING ON ORDERS OVER ₹1,999 <span>•</span> EASY RETURNS</div>
  <header><nav className="nav wrap">
   <button className="mobile-menu icon-button" onClick={()=>setDrawer('menu')} aria-label="Open menu"><Menu/></button>
   <a className="brand" href="#"><span>shop</span>ease.</a>
   <div className="searchbox"><Search size={18}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search products..." /></div>
   <div className="nav-actions">
    <button className="icon-button" onClick={()=>setDrawer('wishlist')} title="Wishlist"><Heart/><span className="nav-label">Wishlist</span><b className="bubble">{wishlist.length}</b></button>
    <button className="icon-button" onClick={()=>setDrawer('cart')} title="Cart"><ShoppingBag/><span className="nav-label">Cart</span><b className="bubble">{count}</b></button>
    <button className="icon-button" onClick={()=>setDrawer('account')} title="Account"><User/><span className="nav-label">{session?'Account':'Login'}</span></button>
   </div>
  </nav></header>
  <main className="wrap">
   <section className="hero"><div><div className="eyebrow">Fresh finds, happy prices</div><h1>Good things.<br/><em>Better everyday.</em></h1><p>Discover thoughtful picks for your home, your style and everything in between. Your next favourite thing is just a click away.</p><button className="button primary" onClick={()=>document.getElementById('shop').scrollIntoView({behavior:'smooth'})}>Shop collection <span>→</span></button></div><div className="hero-art"><div className="hero-circle">🛍️</div><span className="sparkle one">✳</span><span className="sparkle two">✦</span></div></section>
   <section id="shop" className="shop-section">
    <div className="section-title"><div><div className="eyebrow">Curated for you</div><h2>Shop the collection</h2><p className="muted">A little something for every day.</p></div><span className="muted">{visible.length} products</span></div>
    <div className="categories">{categories.map(c=><button key={c} className={category===c?'chip selected':'chip'} onClick={()=>setCategory(c)}>{c}</button>)}</div>
    <div className="product-grid">{visible.map(p=><article className="product-card" key={p.id}>
     <button className={'heart '+(wishlist.includes(p.id)?'hearted':'')} onClick={()=>toggleWish(p.id)} aria-label="Toggle wishlist"><Heart size={18} fill={wishlist.includes(p.id)?'currentColor':'none'}/></button>
     <div className="product-art"><span>{p.emoji}</span></div>
     <div className="product-info"><div className="product-category">{p.category}</div><h3>{p.name}</h3><p className="rating">★★★★★ <span>({p.stock||0} in stock)</span></p><div className="product-bottom"><strong>{money(p.price)}</strong><button className="add-button" onClick={()=>{add(p);notify('Added to your cart')}}><Plus size={18}/></button></div></div>
    </article>)}{!visible.length&&<div className="empty">No products found. Try another search.</div>}</div>
   </section>
   <section className="benefits"><div><span>🚚</span><b>Free delivery</b><small>On orders above ₹1,999</small></div><div><span>↩️</span><b>Easy returns</b><small>Simple, hassle-free returns</small></div><div><span>🔒</span><b>Secure accounts</b><small>Powered by Supabase Auth</small></div></section>
   {isAdmin&&<section className="admin-section"><div className="section-title"><div><div className="eyebrow">Store controls</div><h2>Admin dashboard</h2></div><span className="admin-tag"><ShieldCheck size={15}/> Admin</span></div>
    <form className="admin-form" onSubmit={addProduct}><h3>Add a product</h3><div className="form-grid"><input required placeholder="Product name" value={adminForm.name} onChange={e=>setAdminForm({...adminForm,name:e.target.value})}/><select value={adminForm.category} onChange={e=>setAdminForm({...adminForm,category:e.target.value})}>{categories.slice(1).map(c=><option key={c}>{c}</option>)}</select><input required type="number" min="1" placeholder="Price (₹)" value={adminForm.price} onChange={e=>setAdminForm({...adminForm,price:e.target.value})}/><input placeholder="Emoji (e.g. 🎒)" value={adminForm.emoji} onChange={e=>setAdminForm({...adminForm,emoji:e.target.value})}/><input type="number" min="0" placeholder="Stock" value={adminForm.stock} onChange={e=>setAdminForm({...adminForm,stock:e.target.value})}/><input placeholder="Description" value={adminForm.description} onChange={e=>setAdminForm({...adminForm,description:e.target.value})}/></div><button className="button primary">Add product</button></form>
    <h3 className="admin-subtitle">Your products</h3><div className="admin-list">{products.filter(p=>!String(p.id).startsWith('demo-')).map(p=><div key={p.id}><span>{p.emoji} {p.name} — {money(p.price)}</span><button className="text-danger" onClick={()=>deleteProduct(p.id)}>Hide</button></div>)}{!products.some(p=>!String(p.id).startsWith('demo-'))&&<p className="muted">Products you add will appear here.</p>}</div>
    <h3 className="admin-subtitle">Customer orders</h3>{orders.map(o=><div className="order-row" key={o.id}><span>Order #{o.id.slice(0,8)} · {money(o.total)}</span><select value={o.status} onChange={e=>updateStatus(o.id,e.target.value)}><option value="demo_pending">Demo pending</option><option value="processing">Processing</option><option value="shipped">Shipped</option><option value="delivered">Delivered</option><option value="cancelled">Cancelled</option></select></div>)}
   </section>}
   {session&&<section className="orders-section"><div className="section-title"><div><div className="eyebrow">Your purchases</div><h2>Order history</h2></div></div>{orders.length?orders.map(o=><div className="order-row" key={o.id}><span><Package size={16}/> #{o.id.slice(0,8)} · {money(o.total)}</span><b>{o.status}</b></div>):<p className="muted">Your orders will appear here.</p>}</section>}
  </main>
  <footer><div className="wrap footer-inner"><a className="brand footer-brand" href="#"><span>shop</span>ease.</a><p>Everyday shopping, made easy.</p><small>© 2026 ShopEase. Demo storefront.</small></div></footer>

  <div className={'scrim '+(drawer?'visible':'')} onClick={()=>setDrawer('')}></div>
  <aside className={'drawer '+(drawer?'open':'')} aria-label="Shopping panel">
   <div className="drawer-head"><h2>{drawer==='cart'?'Your cart':drawer==='wishlist'?'Your wishlist':drawer==='account'?'Your account': 'ShopEase menu'}</h2><button className="icon-button" onClick={()=>setDrawer('')}><X/></button></div>
   {drawer==='cart'&&<div className="drawer-content">{cartItems.length?cartItems.map(p=><div className="cart-line" key={p.id}><div className="mini-art">{p.emoji}</div><div className="cart-description"><b>{p.name}</b><small>{money(p.price)} each</small><div className="quantity"><button onClick={()=>change(p.id,-1)}><Minus size={13}/></button>{cart[p.id]}<button onClick={()=>change(p.id,1)}><Plus size={13}/></button><button className="remove" onClick={()=>change(p.id,-cart[p.id])}><Trash2 size={14}/></button></div></div><b>{money(p.price*cart[p.id])}</b></div>):<div className="empty">Your cart is empty. Add something you love!</div>}
    {cartItems.length>0&&<div className="cart-summary"><div><span>Subtotal</span><b>{money(subtotal)}</b></div><div><span>Shipping</span><b>{shipping?money(shipping):'FREE'}</b></div><div className="total-line"><b>Total</b><b>{money(total)}</b></div><button className="button primary full" onClick={placeDemoOrder} disabled={busy}>{busy?'Saving order…':'Place demo order'}</button><small>This creates a demo order only. No payment is collected.</small></div>}</div>}
   {drawer==='wishlist'&&<div className="drawer-content">{products.filter(p=>wishlist.includes(p.id)).map(p=><div className="cart-line" key={p.id}><div className="mini-art">{p.emoji}</div><div className="cart-description"><b>{p.name}</b><small>{money(p.price)}</small><button className="link-button" onClick={()=>add(p)}>Add to cart</button></div><button className="icon-button" onClick={()=>toggleWish(p.id)}><X size={17}/></button></div>)}{!wishlist.length&&<div className="empty">Your wishlist is empty. Tap a heart on a product to save it.</div>}</div>}
   {drawer==='account'&&<div className="drawer-content">{session?<><div className="signed-in"><div className="avatar"><User/></div><b>{profile?.full_name||session.user.email}</b><small>{session.user.email}</small>{isAdmin&&<span className="admin-tag">Administrator</span>}</div><button className="button secondary full" onClick={()=>{setDrawer('');document.querySelector('.orders-section')?.scrollIntoView({behavior:'smooth'})}}>View my orders</button><button className="button outline full" onClick={logout}><LogOut size={16}/> Sign out</button></>:<><div className="auth-tabs"><button className={authMode==='login'?'active':''} onClick={()=>setAuthMode('login')}>Log in</button><button className={authMode==='signup'?'active':''} onClick={()=>setAuthMode('signup')}>Create account</button></div><form className="auth-form" onSubmit={authSubmit}>{authMode==='signup'&&<label>Full name<input required value={fullName} onChange={e=>setFullName(e.target.value)} placeholder="Your name"/></label>}<label>Email address<input type="email" required value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com"/></label><label>Password<input type="password" minLength="6" required value={password} onChange={e=>setPassword(e.target.value)} placeholder="At least 6 characters"/></label><button className="button primary full" disabled={busy}>{busy?'Please wait…':authMode==='login'?'Log in':'Create account'}</button></form><p className="muted tiny">Authentication is securely handled by Supabase after you connect your project.</p></>}</div>}
   {drawer==='menu'&&<div className="drawer-content menu-links"><button onClick={()=>{setDrawer('');document.getElementById('shop').scrollIntoView()}}>Shop products</button><button onClick={()=>setDrawer('wishlist')}>Wishlist</button><button onClick={()=>setDrawer('cart')}>Shopping cart</button><button onClick={()=>setDrawer('account')}>My account</button></div>}
  </aside>
  {!isSupabaseConfigured&&<div className="setup-banner"><b>Preview mode:</b> You're seeing sample products. Follow the README to connect Supabase and activate accounts, database, orders and admin tools.</div>}
  {message&&<div className="toast">{message}</div>}
 </div>;
}
