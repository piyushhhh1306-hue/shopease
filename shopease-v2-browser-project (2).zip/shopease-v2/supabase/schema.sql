-- ShopEase v2 database setup
-- Run this entire file in Supabase Dashboard > SQL Editor > New query.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  role text not null default 'customer' check (role in ('customer','admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  category text not null,
  price numeric(10,2) not null check (price >= 0),
  emoji text default '🛍️',
  description text default '',
  stock integer not null default 0 check (stock >= 0),
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  total numeric(10,2) not null check (total >= 0),
  status text not null default 'demo_pending',
  created_at timestamptz not null default now()
);

create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  product_name text not null,
  quantity integer not null check (quantity > 0),
  unit_price numeric(10,2) not null check (unit_price >= 0)
);

-- Create a profile automatically when a customer signs up.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = ''
as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, new.raw_user_meta_data ->> 'full_name');
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = ''
as $$
  select exists (
    select 1 from public.profiles
    where id = (select auth.uid()) and role = 'admin'
  );
$$;

alter table public.profiles enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;

-- Profiles: each user can read/update their own profile. Do not let users promote themselves.
drop policy if exists "Read own profile" on public.profiles;
create policy "Read own profile" on public.profiles for select to authenticated using (id = (select auth.uid()) or public.is_admin());
drop policy if exists "Update own profile name" on public.profiles;
create policy "Update own profile name" on public.profiles for update to authenticated using (id = (select auth.uid())) with check (id = (select auth.uid()) and role = 'customer');

-- Products: everyone can view active products; admins manage the catalogue.
drop policy if exists "Public can view active products" on public.products;
create policy "Public can view active products" on public.products for select using (active = true or public.is_admin());
drop policy if exists "Admins insert products" on public.products;
create policy "Admins insert products" on public.products for insert to authenticated with check (public.is_admin());
drop policy if exists "Admins update products" on public.products;
create policy "Admins update products" on public.products for update to authenticated using (public.is_admin()) with check (public.is_admin());

-- Orders: customers create/read only their own orders; admins can read/update all.
drop policy if exists "Customers create own orders" on public.orders;
create policy "Customers create own orders" on public.orders for insert to authenticated with check (user_id = (select auth.uid()));
drop policy if exists "Read own orders or admin" on public.orders;
create policy "Read own orders or admin" on public.orders for select to authenticated using (user_id = (select auth.uid()) or public.is_admin());
drop policy if exists "Admins update orders" on public.orders;
create policy "Admins update orders" on public.orders for update to authenticated using (public.is_admin()) with check (public.is_admin());

-- Order line items are accessible only to the order owner or an admin.
drop policy if exists "Create items for own order" on public.order_items;
create policy "Create items for own order" on public.order_items for insert to authenticated
with check (exists (select 1 from public.orders o where o.id = order_id and o.user_id = (select auth.uid())));
drop policy if exists "Read items for own order or admin" on public.order_items;
create policy "Read items for own order or admin" on public.order_items for select to authenticated
using (exists (select 1 from public.orders o where o.id = order_id and (o.user_id = (select auth.uid()) or public.is_admin())));

-- Optional starter products. If the table is empty, the app still shows local demo items.
insert into public.products (name,category,price,emoji,description,stock)
select v.name,v.category,v.price,v.emoji,v.description,v.stock
from (values
 ('Everyday Tote Bag','Accessories',799,'👜','A roomy everyday carry-all.',12),
 ('Minimal Ceramic Mug','Home',449,'☕','A simple mug for slow mornings.',18),
 ('Wireless Headphones','Electronics',2199,'🎧','Comfortable sound for every day.',8),
 ('Classic Wrist Watch','Accessories',1599,'⌚','A clean, timeless everyday style.',7),
 ('Soft Knit Sweater','Fashion',1299,'🧥','A cosy layer for cooler days.',14),
 ('Desk Plant Pot','Home',599,'🪴','A little green for your workspace.',20),
 ('Everyday Sneakers','Fashion',1899,'👟','Easy comfort for daily walks.',9),
 ('Portable Speaker','Electronics',1799,'🔊','Bring your favourite music along.',11)
) as v(name,category,price,emoji,description,stock)
where not exists (select 1 from public.products);
